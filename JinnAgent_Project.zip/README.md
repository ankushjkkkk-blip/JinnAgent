# JinnAgent

A starter native Android Studio project (Java) with a visible, user-started microphone foreground session, notification stop action, basic offline app navigation, flashlight control, and an optional accessibility helper.

## Open/build
1. Open this folder in Android Studio.
2. Allow Gradle to sync and install Android SDK 35 if prompted.
3. Build with `./gradlew assembleDebug` (a Gradle wrapper is not bundled; use Android Studio's installed Gradle or generate a wrapper).

## Termux path
Copy/extract the project to `/storage/emulated/0/JinnAgent`. The source tree is:
`app/src/main/AndroidManifest.xml`
`app/src/main/java/com/jinn/agent/`
`app/src/main/res/`

## Safety and Android limitations
- Microphone use begins only after tapping Start and granting RECORD_AUDIO. A persistent notification is shown; Stop ends the session.
- Android may restrict microphone foreground-service starts while the app is in the background. Speech recognition availability and offline language support depend on the device's installed speech services.
- WakeLock is time-limited and released when the service stops.
- Accessibility is optional and must be enabled manually in Android Settings. The helper does not inspect other apps' text or auto-click Send/Submit. It only provides a focused-field fill method for explicitly approved text.
- External messages, posts, purchases, and submissions are not executed automatically; review and confirm them in the destination app.
- Flashlight and app launch availability depend on device hardware and installed packages.

This is a starter project, not a guaranteed prebuilt APK. Compile on a machine with a compatible Android SDK/Gradle setup.
