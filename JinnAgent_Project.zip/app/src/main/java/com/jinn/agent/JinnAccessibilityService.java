package com.jinn.agent;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Optional, user-enabled helper. It does not read page contents, click buttons,
 * or send messages. It only exposes a deliberate fillFocusedField call for a
 * future UI flow after the user explicitly approves the text.
 */
public class JinnAccessibilityService extends AccessibilityService {
    private static JinnAccessibilityService instance;
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* Intentionally no surveillance. */ }
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { instance=null; super.onDestroy(); }

    public static boolean fillFocusedField(String approvedText) {
        if(instance==null || approvedText==null) return false;
        AccessibilityNodeInfo root=instance.getRootInActiveWindow();
        if(root==null) return false;
        AccessibilityNodeInfo focus=root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if(focus==null || !focus.isEditable()) return false;
        android.os.Bundle args=new android.os.Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,approvedText);
        return focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args);
    }
}
