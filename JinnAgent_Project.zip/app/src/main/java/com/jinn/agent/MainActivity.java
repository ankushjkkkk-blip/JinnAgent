package com.jinn.agent;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.*;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(28,28,28,28);
        page.setBackgroundColor(Color.rgb(5,10,24));
        TextView orb = new TextView(this);
        orb.setText("✦");
        orb.setTextSize(72);
        orb.setTextColor(Color.rgb(65,190,255));
        orb.setGravity(Gravity.CENTER);
        page.addView(orb, new LinearLayout.LayoutParams(-1,220));
        TextView title = new TextView(this);
        title.setText("JinnAgent");
        title.setTextSize(28);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        page.addView(title);
        status = new TextView(this);
        status.setText("Ready. Listening starts only when you choose.");
        status.setTextColor(Color.LTGRAY);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0,18,0,22);
        page.addView(status);
        Button start = new Button(this); start.setText("Start voice assistant");
        start.setOnClickListener(v -> startAssistant());
        page.addView(start, new LinearLayout.LayoutParams(-1,-2));
        Button stop = new Button(this); stop.setText("Stop assistant");
        stop.setOnClickListener(v -> { stopService(new Intent(this,JinnBackgroundService.class)); status.setText("Assistant stopped."); });
        page.addView(stop, new LinearLayout.LayoutParams(-1,-2));
        Button flashlight = new Button(this); flashlight.setText("Toggle flashlight");
        flashlight.setOnClickListener(v -> {
            Intent i = new Intent(this,JinnBackgroundService.class).setAction(JinnBackgroundService.ACTION_FLASH);
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("Flashlight command requested.");
        });
        page.addView(flashlight, new LinearLayout.LayoutParams(-1,-2));
        Button accessibility = new Button(this); accessibility.setText("Accessibility settings (optional)");
        accessibility.setOnClickListener(v -> startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        page.addView(accessibility, new LinearLayout.LayoutParams(-1,-2));
        setContentView(page);
    }
    private void startAssistant() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10); return;
        }
        Intent i = new Intent(this,JinnBackgroundService.class).setAction(JinnBackgroundService.ACTION_START);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Voice service active. Use the notification to stop.");
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r==10 && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) startAssistant();
    }
}
