package com.jinn.agent;

import android.app.*;
import android.content.*;
import android.hardware.camera2.*;
import android.os.*;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.*;

public class JinnBackgroundService extends Service {
    public static final String ACTION_START="com.jinn.agent.START";
    public static final String ACTION_FLASH="com.jinn.agent.FLASH";
    private static final String CHANNEL="jinn_agent_service";
    private PowerManager.WakeLock wakeLock;
    private SpeechRecognizer recognizer;
    private CameraManager camera;
    private boolean flashOn=false;

    @Override public void onCreate() {
        super.onCreate();
        camera=(CameraManager)getSystemService(CAMERA_SERVICE);
        createChannel();
    }
    @Override public int onStartCommand(Intent intent,int flags,int id) {
        String action=intent==null?ACTION_START:intent.getAction();
        if (ACTION_FLASH.equals(action)) { toggleFlash(); return START_NOT_STICKY; }
        startForeground(41, notification());
        acquireWakeLock();
        startRecognition();
        return START_NOT_STICKY;
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel(CHANNEL,"JinnAgent voice session",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Intent stop=new Intent(this,JinnBackgroundService.class).setAction("STOP");
        PendingIntent pi=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,CHANNEL).setContentTitle("JinnAgent is active")
            .setContentText("Microphone session active — tap Stop to end.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(new Notification.Action.Builder(null,"Stop",pi).build()).build();
    }
    private void acquireWakeLock() {
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"JinnAgent:Voice");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire(10*60*1000L);
    }
    private void startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;
        if (recognizer!=null) recognizer.destroy();
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float v) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onError(int e) { /* No silent restart loop. User can restart from the app. */ }
            public void onResults(Bundle b) {
                ArrayList<String> matches=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(matches!=null && !matches.isEmpty()) handleCommand(matches.get(0));
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t,Bundle b) {}
        });
        Intent speech=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");
        speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"hi-IN");
        recognizer.startListening(speech);
    }
    private void handleCommand(String text) {
        String s=text.toLowerCase(Locale.ROOT);
        if(s.contains("flashlight") || s.contains("torch") || s.contains("टॉर्च")) toggleFlash();
        else if(s.contains("youtube")) openApp("com.google.android.youtube");
        else if(s.contains("whatsapp")) openApp("com.whatsapp");
        else if(s.contains("camera")) openApp("com.android.camera2");
        // Messages, purchases, posts and other external actions are never sent automatically.
    }
    private void openApp(String pkg) {
        Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
        if(i!=null){ i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
    }
    private void toggleFlash() {
        try {
            String[] ids=camera.getCameraIdList();
            for(String id:ids) {
                CameraCharacteristics c=camera.getCameraCharacteristics(id);
                Boolean has=c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing=c.get(CameraCharacteristics.LENS_FACING);
                if(Boolean.TRUE.equals(has) && facing!=null && facing==CameraCharacteristics.LENS_FACING_BACK) {
                    flashOn=!flashOn; camera.setTorchMode(id,flashOn); break;
                }
            }
        } catch(Exception ignored) {}
    }
    @Override public void onDestroy() {
        if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}
        if(wakeLock!=null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
